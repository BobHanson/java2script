Clazz.declarePackage("com.jcraft.jzlib");
Clazz.load(["java.io.IOException"], "com.jcraft.jzlib.ZStreamException", null, function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "ZStreamException", java.io.IOException);
});
;//5.0.1-v7 Wed May 07 03:32:58 CDT 2025
