Clazz.declarePackage("com.jcraft.jzlib");
(function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "GZIPInputStream", null);
})();
;//5.0.1-v7 Mon May 12 23:42:45 CDT 2025
