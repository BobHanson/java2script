Clazz.declareInterface(java.io, "Serializable");
;//5.0.1-v7 Mon May 12 23:42:45 CDT 2025
