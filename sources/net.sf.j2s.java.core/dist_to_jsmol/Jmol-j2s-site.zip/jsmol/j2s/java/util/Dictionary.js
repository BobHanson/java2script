(function(){
var c$ = Clazz.declareType(java.util, "Dictionary", null);
})();
;//5.0.1-v7 Mon May 12 23:42:45 CDT 2025
