Clazz.declarePackage("java.util.zip");
(function(){
var c$ = Clazz.declareInterface(java.util.zip, "ZipConstants");
c$.LOCSIG = 0x04034b50;
c$.EXTSIG = 0x08074b50;
c$.CENSIG = 0x02014b50;
c$.ENDSIG = 0x06054b50;
})();
;//5.0.1-v7 Mon May 12 23:42:45 CDT 2025
