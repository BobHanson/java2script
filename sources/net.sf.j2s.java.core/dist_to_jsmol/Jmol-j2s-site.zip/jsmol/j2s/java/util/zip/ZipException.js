Clazz.declarePackage("java.util.zip");
Clazz.load(["java.io.IOException"], "java.util.zip.ZipException", null, function(){
var c$ = Clazz.declareType(java.util.zip, "ZipException", java.io.IOException);
});
;//5.0.1-v7 Mon May 12 23:42:45 CDT 2025
