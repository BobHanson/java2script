(function(){
var c$ = Clazz.declareInterface(java.util, "Map");
Clazz.declareInterface(java.util.Map, "Entry");
c$.NOT_SIMPLE = 0;
c$.INVALID_KEY = 1;
c$.NO_SUCH_KEY = 2;
c$.HAS_KEY = 3;
})();
;//5.0.1-v7 Wed May 07 03:32:58 CDT 2025
