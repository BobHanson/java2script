Clazz.declarePackage("java.util.zip");
Clazz.load(["com.jcraft.jzlib.CRC32"], "java.util.zip.CRC32", null, function(){
var c$ = Clazz.declareType(java.util.zip, "CRC32", com.jcraft.jzlib.CRC32);
});
;//5.0.1-v7 Wed May 07 03:32:58 CDT 2025
