Clazz.declareInterface(java.util, "Collection", Iterable);
;//5.0.1-v7 Wed May 07 03:32:58 CDT 2025
