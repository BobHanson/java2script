Clazz.declarePackage("java.util.zip");
(function(){
var c$ = Clazz.declareType(java.util.zip, "ZipConstants64", null);
})();
;//5.0.1-v7 Mon May 12 23:42:45 CDT 2025
