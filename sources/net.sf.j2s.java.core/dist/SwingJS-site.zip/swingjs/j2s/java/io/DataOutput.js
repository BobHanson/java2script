(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DataOutput");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-11-07 11:08:31 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
