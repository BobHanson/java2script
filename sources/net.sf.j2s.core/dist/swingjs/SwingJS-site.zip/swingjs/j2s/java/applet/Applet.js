(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Applet", null, 'swingjs.a2s.Applet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-09-20 18:32:14 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
