(function(){var P$=Clazz.newPackage("java.awt.image.renderable"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "RenderableImage");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-11-19 18:36:45 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
