(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "MenuContainer");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-11-01 10:31:08 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
